#include<iostream>
using namespace std;
int main()
{
// ALI ARSHAD A7 L1F26BSCS0283
cout << "Hello WOrld!";
cout << "\nUniversity of Central Punjab\nFaculty of Information Technology\nOrientation Day 2026";
cout << "\nwelcome!" << endl;
cout << "2026\n45\n135\n1250\n";
cout << "Total fee:" << 45000 + 9000 << endl;


//Task 2
	//part A
// first error was(using namespace std;) were msiing
cout << " PArt A ( corrected program)\n";
cout << "Orientation Day" << endl; // semi colon(;) was missing
cout << "Total students:" << 450 << endl; // (<<) was msiing
cout << "Seats left:" << 500 - 450 << endl;
cout << "Have a nice day" << endl; // ("") was missing

//part B
cout << "Average: " << (60 + 70 + 80) / 3 << endl; // [()] were missing

//Task 3
cout << "Expresssion 1:" << 10 + 5 + 2 << endl;
cout << "Expresssion 2:" << (10 + 5) * 2 << endl;
cout << "Expresssion 3:" << 20 - 5 - 3 << endl;
cout << "Expresssion 4:" << 100 / 7 << endl;
cout << "Expresssion 5:" << 100 % 7 << endl;
cout << "Expresssion 6:" << 2 * 3 + 8 / 4 - 1 << endl;
cout << "Expresssion 7:" << 2 *(3 + 8 / 4 - 1) << endl;


//Task 4
    // Declare and initialize variables.
    int rollNo = 1045;
    int semester = 1;
    char section = 'B';
    double cgpa = 3.5;
    int totalFee = 45000;
    int feePaid = 20000;

    // Display the student's original information.
    cout << "Roll No: " << rollNo << endl;
    cout << "Semester: " << semester << endl;
    cout << "Section: " << section << endl;
    cout << "CGPA: " << cgpa << endl;
    cout << "Total Fee: " << totalFee << endl;
    cout << "Fee Paid: " << feePaid << endl;

    // Move to the next semester.
    semester = semester + 1;

    // Add the second installment.
    feePaid = feePaid + 5000;

    // Calculate the remaining fee and percentage paid.
    int remainingFee = totalFee - feePaid;
    int percentagePaid = feePaid * 100 / totalFee;

    // Display the updated information.
    cout << "Semester: " << semester << endl;
    cout << "Fee Paid: " << feePaid << endl;
    cout << "Remaining Fee: " << remainingFee << endl;
    cout << "Percentage Paid: " << percentagePaid << endl;

    // Valid and invalid identifiers:
    // 2ndYear: Invalid (starts with a digit)
    // student_name: Valid
    // total-marks: Invalid (contains a hyphen)
    // _fee: Valid identifier
    // Roll No: Invalid (contains a space)
    // marks2: Valid
    // Observation: An uninitialized int has an unpredictable value.
    // It is not safe to rely on that value.


    //Task 5
        // Declare variables.
        int age, creditHours, feePerCreditHour;

        // Take age as input.
        cout << "Enter age: ";
        cin >> age;

        // Take credit hours as input.
        cout << "Enter credit hours: ";
        cin >> creditHours;

        // Take fee per credit hour as input.
        cout << "Enter fee per credit hour: ";
        cin >> feePerCreditHour;

        // Calculate the total fee.
        int totalFeeTask5 = creditHours * feePerCreditHour;

        // Calculate fee after discount.
        int feeAfterDiscount = totalFeeTask5 - 2000;

        // Calculate the year of birth and year the student turns 25.
        int birthYear = 2026 - age;
        int yearTurns25 = birthYear + 25;

        // Display the results.
        cout << "Total fee: " << totalFeeTask5 << endl;
        cout << "Fee after discount: " << feeAfterDiscount << endl;
        cout << "Year of birth: " << birthYear << endl;
        cout << "Year turning 25: " << yearTurns25 << endl;

        // Observation: Spaces, tabs, and newlines separate integer inputs.
        // If age is entered as 19.8, cin >> age stores 19.
        // The remaining .8 can interfere with the next integer input.


        //Task 6
            // Input the price and quantity.
            int price, quantity;
            cout << "Enter price and quantity: ";
            cin >> price >> quantity;

            // Calculate the total.
            int total = price * quantity;

            // Calculate 5% tax.
            int tax = total * 5 / 100;

            // Calculate the grand total.
            int grandTotal = total + tax;

            // Display the bill.
            cout << "total = " << total << endl;
            cout << "tax = " << tax << endl;
            cout << "grandTotal = " << grandTotal << endl;

            

        
    
return 0;

}